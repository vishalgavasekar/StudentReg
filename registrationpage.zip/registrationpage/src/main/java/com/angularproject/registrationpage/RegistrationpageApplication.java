package com.angularproject.registrationpage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationpageApplication.class, args);
	}

}
